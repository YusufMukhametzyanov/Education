const featuredItems = `[
  {
    "title": "ELLERY X M'O CAPSULE",
    "img": "img/body4_picture1.png",
    "discription":
      "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "title": "ELLERY X M'O CAPSULE",
    "img": "img/body4_picture2.png",
    "discription":
      "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "title": "ELLERY X M'O CAPSULE",
    "img": "img/body4_picture3.png",
    "discription":
      "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "title": "ELLERY X M'O CAPSULE",
    "img": "img/body4_picture4.png",
    "discription":
      "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "title": "ELLERY X M'O CAPSULE",
    "img": "img/body4_picture5.png",
    "discription":
      "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "title": "ELLERY X M'O CAPSULE",
    "img": "img/body4_picture6.png",
    "discription":
      "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  }
]`;
